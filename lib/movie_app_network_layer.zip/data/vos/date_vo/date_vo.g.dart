// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'date_vo.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DatesVO _$DatesVOFromJson(Map<String, dynamic> json) => DatesVO(
      maximum: json['maximum'] as String?,
      minimum: json['minimum'] as String?,
    );

Map<String, dynamic> _$DatesVOToJson(DatesVO instance) => <String, dynamic>{
      'maximum': instance.maximum,
      'minimum': instance.minimum,
    };
