import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:movie_app/constant/dimens.dart';
import 'package:movie_app/data/models/movie_model.dart';
import 'package:movie_app/data/models/movie_model_imp.dart';
import 'package:movie_app/data/vos/productionCompanies_vo/production_companies_vo.dart';
import 'package:movie_app/widgets/sliverappbar_widget.dart';
import '../constant/assest_images.dart';
import '../constant/strings.dart';
  final MovieModel _movieData=  MovieModelImpl();
class MovieDetailScreen extends StatelessWidget {
  const MovieDetailScreen({Key? key, this.movieID}) : super(key: key);
  final int? movieID ;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SliverAppBarWidget(expandedHeight: kPS400px, centerTitle:true, dataFuture:_movieData.getMovieDetails(movieID!), builder: (context,snapShot){
        if(snapShot.connectionState == ConnectionState.waiting){
          return const Center(child: CircularProgressIndicator(color: Colors.red,),);
        }else if(snapShot.hasError){
          return  Center(child: Image.asset("images/place_holder.jpg"),);
        }else {
          final movieData = snapShot.data;
          return CachedNetworkImage(imageUrl: "https://image.tmdb.org/t/p/w500/${movieData?.backdropPath}",fit: BoxFit.fill,errorWidget:(context,url,error)=>const Center(child: CircularProgressIndicator(),),);
        }
      }, textBuilder: (context,snapShot){
        if(snapShot.connectionState == ConnectionState.waiting){
          return const Center(child: Text(""));
        }else if(snapShot.hasError){
          return const Center(child: Text("errorTitle"),);
        }else {
          final movieData = snapShot.data;
          return Text("${movieData?.title}",style: const TextStyle(color: Colors.white,fontSize: 16),);
        }
      }, bodyBuilder: (context,snapShot){
        if(snapShot.connectionState == ConnectionState.waiting){
          return const Center(child: CircularProgressIndicator(color: Colors.red,),);
        }else if(snapShot.hasError){
          return const Center(child: Text("error"),);
        }else {
          final movieData = snapShot.data;
          return SingleChildScrollView(
            child: Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(
                  left: kPS10px, right: kPS10px, top: kPS20px),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    kStoryLineText,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: kPS16px,
                        color: Colors.white),
                  ),
                  const SizedBox(
                    height: kPS10px,
                  ),
                  Text(
                    "${movieData?.overview}",
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, color: Colors.white70),
                    textAlign: TextAlign.justify,
                  ),
                  const SizedBox(
                    height: kPS10px,
                  ),
                  const Text(
                    kStarCastText,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.white),
                  ),
                  // StarCastTalentWidget(images: actorData),
                  const Text(
                    kTalentSquadText,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.white),
                  ),
                  // StarCastTalentWidget(images: actorData),
                  const Text(
                    kCompanyText,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.white),
                  ),
                 FutureBuilder<List<ProductionCompaniesVO>?>(future: _movieData.getCompanyList(movieID!),builder: (context,snapShot){
                   if(snapShot.connectionState == ConnectionState.waiting){
                     return const Center(child: CircularProgressIndicator(color: Colors.red,),);
                   }else if(snapShot.hasError){
                     return const Center(child: Text("errorTitle"),);
                   }else {
                     final movieData = snapShot.data;
                     return SizedBox(
                       height: 125,
                       child: ListView.builder(
                         scrollDirection: Axis.horizontal,
                           itemCount: movieData?.length,itemBuilder: (context,index){
                         return Container(
                           alignment: Alignment.center,
                           width: 100,
                           margin: const EdgeInsets.all(10),
                           child: Column(
                             children: [
                               CircleAvatar(
                           backgroundColor:Colors.white.withOpacity(0.5),
                                 child: ClipRRect(
                                   borderRadius:BorderRadius.circular(20),
                                   child: CachedNetworkImage(
                                     width: 50,
                                     height: 50,
                                     imageUrl: "https://image.tmdb.org/t/p/w500/${movieData?[index].logoPath}",
                                   placeholder: (context,url)=> Image.asset("images/place_holder.jpg"),
                                   errorWidget: (context,url,error)=>Image.asset("images/place_holder.jpg"),),
                                 ),
                               ),
                                const SizedBox(height: 10,),
                                Wrap(children: [
                                 Text("${movieData?[index].name}",style: const TextStyle(color: Colors.white),textAlign:TextAlign.center,),
                               ],),
                             ],
                           ),
                         );
                       }),
                     );
                   }
                 }),
                  const Text(
                    kRecommendedText,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: kPS16px,
                        color: Colors.white),
                  ),
                ],
              ),
            ),
          );
        }
      }),
    );
  }
}