
List<Map<String,String>> movieData = [
{"image":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcST3K072b_E1EQeFnzfzMBbiMcD_XiF2HIkhg&usqp=CAU","name":"BLACK ADAM","rating":"6.4","votes":"5432"},
{"image":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcScH15cLFHuj8ovdVjE6pOT3gOMDv6mepbUOQ&usqp=CAU","name":"SHAZAM","rating":"6.4","votes":"12345"},
{"image":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcST3K072b_E1EQeFnzfzMBbiMcD_XiF2HIkhg&usqp=CAU","name":"BLACK ADAM","rating":"6.4","votes":"5432"},
{"image":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwdxavVSAa7uxSwa3levomQ_8j8yTjdOUTsw&usqp=CAU","name":"No Way Home","rating":"6.4","votes":"8883"},
{"image":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRkGi0J4GlN2kwxt1fRj9JaWYeHfeeHB5A7Tw&usqp=CAU","name":"ANT-MAN","rating":"6.4","votes":"1234"},
];
List<Map<String,String>> actorData = [
{"image":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSsFttNQWrDLqv2-Oag4j-RN-J9fYDWhTDmkg&usqp=CAU","name":"The Rock","type":"Actor"},
{"image":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSpTqf0dXUHBJKfcSQX3k_Wvs7IhUZlhm8t1A&usqp=CAU","name":"Sharukh khan","type":"Actor"},
{"image":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTvHF2nbv-Dsdblp4cSwORdUfzVlh20uDdLuw&usqp=CAU","name":"John Wick","type":"Actor"},
{"image":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS6VqbNzBDX_OrOvWmBg64M5V4p7oguRtqklQ&usqp=CAU","name":"Scarlett","type":"Actor"},
];
List<Map<String,String>> companyData = [
{"image":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0V_Z188h8k8kPXl1kX3un3SE1W4qcnyKSMw&usqp=CAU","name":"NetFlix"},
{"image":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7YLdMm7MO5H9dxReaWq-8QojmyAF8L5-U4g&usqp=CAU","name":"20th Century Fox"},
];

