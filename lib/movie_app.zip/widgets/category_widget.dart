// import 'package:flutter/material.dart';
// class Categories extends StatelessWidget {
//   const Categories({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 10),
//       decoration: BoxDecoration(borderRadius: BorderRadius.circular(5)),
//       child: Text(categoryTitles[index],style: const TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 16),),
//     );
//   }
// }
